#include<iostream>
using namespace std;
int main()
{
     cout<<"Price of item 1 = $15"<<endl;
     cout<<"Price of item 2 = $24.95"<<endl;
     cout<<"Price of item 3 = $6.95"<<endl;
     cout<<"Price of item 4 = $12"<<endl;
     cout<<"Price of item 5 = $3.5"<<endl;

     return 0;
}
~                                                                               
~             