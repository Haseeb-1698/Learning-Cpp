#include<iostream>
using namespace std;
int main()
{
     cout<<"*****************"<<endl;
     cout<<"**             **"<<endl;
     cout<<"***           ***"<<endl;
     cout<<"****         ****"<<endl;
     cout<<"*****       *****"<<endl;
     cout<<"******     ******"<<endl;
     cout<<"*******   *******"<<endl;
     cout<<"******** ********"<<endl;
     cout<<"*****************"<<endl;
     cout<<"Program 3 Part 2"<<endl<<endl;
     cout<<"         ***         "<<endl;
     cout<<"       *******       "<<endl;
     cout<<"*********************"<<endl;
     cout<<"******        *******"<<endl;
     cout<<"  *****       *****  "<<endl;
     cout<<"  *****************  "<<endl;
     cout<<"     ***********     "<<endl;
     cout<<"        *****        "<<endl;
     cout<<"         ***         "<<endl;
     cout<<"Program 3 Part 3"<<endl<<endl;
     cout<<"          *          "<<endl;
     cout<<"       *     *       "<<endl;
     cout<<"    *           *    "<<endl;
     cout<<" *                 * "<<endl;
     cout<<"    *           *    "<<endl;
     cout<<"       *     *       "<<endl;
     cout<<"          *          "<<endl;


     return 0;
}

