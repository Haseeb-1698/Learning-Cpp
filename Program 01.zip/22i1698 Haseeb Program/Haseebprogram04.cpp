#include<iostream>
using namespace std;
int main()
{
     cout<<"MY Dog's name is \"Tony\" \n He is a 3 year old    =>    \""
Rottweiler\"  <="<<endl;


     return 0;
}
