#include<iostream>
using namespace std;
int main()
{
     cout<<"Muhammad Haseeb(22i-1698)"<<endl;
     cout<<"Address A-383 P.M Colony Wah cantt Pakistan 47040zip"<<endl;
     cout<<"Number 03315955899"<<endl;
     cout<<"BS CY Section D"<<endl;
     return 0;
}
